package com.customer.controller;




import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.customer.domain.CustomerTable;
import com.customer.domain.Userforlg;
import com.customer.service.customerService;

@Controller
public class Homecontroller {

	@Autowired
	private customerService cs;
	

	
	@RequestMapping("/")
	public String home()
	{
		return "index";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public String addcustomer(Model model)
	{
		Userforlg user =new Userforlg();
		model.addAttribute("user",user);
		return "addnewcustomer";
	
	}
	@RequestMapping(value="/add" , method=RequestMethod.POST)
	public String savecustomer(@ModelAttribute ("user") Userforlg user,HttpServletRequest request)
	{
		cs.save(user);	
		return "redirect:/add";
	}
	
	@RequestMapping(value="/newcustomergst", method=RequestMethod.GET)
	public String newcustomergst(Model model)
	{
		CustomerTable ct =new CustomerTable();
		List<Userforlg> customerList = cs.findAll();
		model.addAttribute("customerList", customerList);
		model.addAttribute("ct",ct);
		return "addnewcustomergst";
	
	}
	@RequestMapping(value="/newcustomergst" , method=RequestMethod.POST)
	public String savecustomergst(@ModelAttribute ("ct") CustomerTable ct,HttpServletRequest request)
	{ 
		 Userforlg user = cs.findByGSTIN(ct.getGSTIN());
	   System.out.print(user);
		cs.save(ct,user);	
		return "redirect:/newcustomergst";
	}
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String listofcustomertable(Model model)
	{
		List<CustomerTable> customerList = cs.findAlls();
		model.addAttribute("customerList", customerList);
		return "index";
	}
	
}
