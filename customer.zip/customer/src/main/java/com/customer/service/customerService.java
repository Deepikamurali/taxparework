package com.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.domain.CustomerTable;
import com.customer.domain.Userforlg;
import com.customer.repository.CustomerGstRepository;
import com.customer.repository.customerRepository;

@Service
public class customerService {

	@Autowired
	private customerRepository cR;
	@Autowired
	private CustomerGstRepository cgr;
	public void save(Userforlg user) {
         cR.save(user);
		
	}

	public void save(CustomerTable ct, Userforlg user) {
		
		//CustomerTable ct1 =new CustomerTable();
		ct.setCustomer(user);
		 cgr.save(ct);
		
	}

	public List<Userforlg> findAll() {
		// TODO Auto-generated method stub
		return (List<Userforlg>) cR.findAll();
	}

	

	public Userforlg findByGSTIN(String gstin) {
		// TODO Auto-generated method stub
		return cR.findByGSTIN(gstin);
	}

	public List<CustomerTable> findAlls() {
		// TODO Auto-generated method stub
		return (List<CustomerTable>) cgr.findAll();
	}
}