package com.customer.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class CustomerTable {

	
	//@Column(name = "address_id")
	@Id
	@Column(columnDefinition = "varchar(15)", nullable=false)
	private String GSTIN;
	 
    
	@Column(columnDefinition = "integer(4)")
	private Integer period;
	
	private Integer year;
	
	private String BillingType;
	
	private String FirmType;
	private String FinancialYear;
	
	
	@OneToOne(cascade=CascadeType.ALL)
	 @JoinColumn(name="user_id")
	 private  Userforlg customer;
	 
	@Column(columnDefinition = "CHAR(1)")
	private String Q1_GSTR1_04;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q1_GSTR3B_04;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q1_GSTR1_05;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q1_GSTR3B_05;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q1_GSTR1_06;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q1_GSTR3B_06;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q2_GSTR1_07;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q2_GSTR3B_07;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q2_GSTR1_08;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q2_GSTR3B_08;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q2_GSTR1_09;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q2_GSTR3B_09;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q3_GSTR1_10;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q3_GSTR3B_10;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q3_GSTR1_11;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q3_GSTR3B_11;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q3_GSTR1_12;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q3_GSTR3B_12;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q4_GSTR1_01;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q4_GSTR3B_01;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q4_GSTR1_02;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q4_GSTR3B_02;
	
	@Column(columnDefinition = "CHAR(1)")
	private String Q4_GSTR1_03;
	
	@Column(columnDefinition = "CHAR(1)")
	private String  Q4_GSTR3B_03;
	
	public String getGSTIN() {
		return GSTIN;
	}

	public void setGSTIN(String gSTIN) {
		GSTIN = gSTIN;
	}

	public Integer getPeriod() {
		return period;
	}

	public void setPeriod(Integer period) {
		this.period = period;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public String getBillingType() {
		return BillingType;
	}

	public void setBillingType(String billingType) {
		BillingType = billingType;
	}

	public String getFirmType() {
		return FirmType;
	}

	public void setFirmType(String firmType) {
		FirmType = firmType;
	}

	public String getFinancialYear() {
		return FinancialYear;
	}

	public void setFinancialYear(String financialYear) {
		FinancialYear = financialYear;
	}

	public String getQ1_GSTR1_04() {
		return Q1_GSTR1_04;
	}

	public void setQ1_GSTR1_04(String q1_GSTR1_04) {
		Q1_GSTR1_04 = q1_GSTR1_04;
	}

	public String getQ1_GSTR3B_04() {
		return Q1_GSTR3B_04;
	}

	public void setQ1_GSTR3B_04(String q1_GSTR3B_04) {
		Q1_GSTR3B_04 = q1_GSTR3B_04;
	}

	public String getQ1_GSTR1_05() {
		return Q1_GSTR1_05;
	}

	public void setQ1_GSTR1_05(String q1_GSTR1_05) {
		Q1_GSTR1_05 = q1_GSTR1_05;
	}

	public String getQ1_GSTR3B_05() {
		return Q1_GSTR3B_05;
	}

	public void setQ1_GSTR3B_05(String q1_GSTR3B_05) {
		Q1_GSTR3B_05 = q1_GSTR3B_05;
	}

	public String getQ1_GSTR1_06() {
		return Q1_GSTR1_06;
	}

	public void setQ1_GSTR1_06(String q1_GSTR1_06) {
		Q1_GSTR1_06 = q1_GSTR1_06;
	}

	public String getQ1_GSTR3B_06() {
		return Q1_GSTR3B_06;
	}

	public void setQ1_GSTR3B_06(String q1_GSTR3B_06) {
		Q1_GSTR3B_06 = q1_GSTR3B_06;
	}

	public Userforlg getCustomer() {
		return customer;
	}

	public void setCustomer(Userforlg customer) {
		this.customer = customer;
	}

	public String getQ2_GSTR1_07() {
		return Q2_GSTR1_07;
	}

	public void setQ2_GSTR1_07(String q2_GSTR1_07) {
		Q2_GSTR1_07 = q2_GSTR1_07;
	}

	public String getQ2_GSTR3B_07() {
		return Q2_GSTR3B_07;
	}

	public void setQ2_GSTR3B_07(String q2_GSTR3B_07) {
		Q2_GSTR3B_07 = q2_GSTR3B_07;
	}

	public String getQ2_GSTR1_08() {
		return Q2_GSTR1_08;
	}

	public void setQ2_GSTR1_08(String q2_GSTR1_08) {
		Q2_GSTR1_08 = q2_GSTR1_08;
	}

	public String getQ2_GSTR3B_08() {
		return Q2_GSTR3B_08;
	}

	public void setQ2_GSTR3B_08(String q2_GSTR3B_08) {
		Q2_GSTR3B_08 = q2_GSTR3B_08;
	}

	public String getQ2_GSTR1_09() {
		return Q2_GSTR1_09;
	}

	public void setQ2_GSTR1_09(String q2_GSTR1_09) {
		Q2_GSTR1_09 = q2_GSTR1_09;
	}

	public String getQ2_GSTR3B_09() {
		return Q2_GSTR3B_09;
	}

	public void setQ2_GSTR3B_09(String q2_GSTR3B_09) {
		Q2_GSTR3B_09 = q2_GSTR3B_09;
	}

	public String getQ3_GSTR1_10() {
		return Q3_GSTR1_10;
	}

	public void setQ3_GSTR1_10(String q3_GSTR1_10) {
		Q3_GSTR1_10 = q3_GSTR1_10;
	}

	public String getQ3_GSTR3B_10() {
		return Q3_GSTR3B_10;
	}

	public void setQ3_GSTR3B_10(String q3_GSTR3B_10) {
		Q3_GSTR3B_10 = q3_GSTR3B_10;
	}

	public String getQ3_GSTR1_11() {
		return Q3_GSTR1_11;
	}

	public void setQ3_GSTR1_11(String q3_GSTR1_11) {
		Q3_GSTR1_11 = q3_GSTR1_11;
	}

	public String getQ3_GSTR3B_11() {
		return Q3_GSTR3B_11;
	}

	public void setQ3_GSTR3B_11(String q3_GSTR3B_11) {
		Q3_GSTR3B_11 = q3_GSTR3B_11;
	}

	public String getQ3_GSTR1_12() {
		return Q3_GSTR1_12;
	}

	public void setQ3_GSTR1_12(String q3_GSTR1_12) {
		Q3_GSTR1_12 = q3_GSTR1_12;
	}

	public String getQ3_GSTR3B_12() {
		return Q3_GSTR3B_12;
	}

	public void setQ3_GSTR3B_12(String q3_GSTR3B_12) {
		Q3_GSTR3B_12 = q3_GSTR3B_12;
	}

	public String getQ4_GSTR1_01() {
		return Q4_GSTR1_01;
	}

	public void setQ4_GSTR1_01(String q4_GSTR1_01) {
		Q4_GSTR1_01 = q4_GSTR1_01;
	}

	public String getQ4_GSTR3B_01() {
		return Q4_GSTR3B_01;
	}

	public void setQ4_GSTR3B_01(String q4_GSTR3B_01) {
		Q4_GSTR3B_01 = q4_GSTR3B_01;
	}

	public String getQ4_GSTR1_02() {
		return Q4_GSTR1_02;
	}

	public void setQ4_GSTR1_02(String q4_GSTR1_02) {
		Q4_GSTR1_02 = q4_GSTR1_02;
	}

	public String getQ4_GSTR3B_02() {
		return Q4_GSTR3B_02;
	}

	public void setQ4_GSTR3B_02(String q4_GSTR3B_02) {
		Q4_GSTR3B_02 = q4_GSTR3B_02;
	}

	public String getQ4_GSTR1_03() {
		return Q4_GSTR1_03;
	}

	public void setQ4_GSTR1_03(String q4_GSTR1_03) {
		Q4_GSTR1_03 = q4_GSTR1_03;
	}

	public String getQ4_GSTR3B_03() {
		return Q4_GSTR3B_03;
	}

	public void setQ4_GSTR3B_03(String q4_GSTR3B_03) {
		Q4_GSTR3B_03 = q4_GSTR3B_03;
	}

	
	//private Long id;
	//private String username;
	
	
}
