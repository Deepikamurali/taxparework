package com.customer.domain;




import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;





@Entity
//public class Userforlg implements UserDetails{
public class Userforlg
{
	//@Column(name="...", table="...", insertable=true, updateable=false,
	  //        columndefinition="NUMBER(5,2) NOT NULL UNIQUE"
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(columnDefinition = "varchar(35)  NOT NULL UNIQUE ",updatable= true)
	private String company_Name;
	
	@Column(columnDefinition = "varchar(25)  NOT NULL  ",updatable= true)
	private String proprietor_Name;
	
	@Column(columnDefinition = "varchar(25)")
	private String father_Name;
	

	private Date Date_of_birth;
	

	@Column(columnDefinition = "varchar(10)  NOT NULL UNIQUE",updatable= true)
	private String pan_No;
	
	@Column(columnDefinition = "BigInt(12) NOT NULL UNIQUE")
	private Long Aadhaar_No;
	
	@Column(columnDefinition = "varchar(12)")
	private String Aadhaar_ADDRESS;
	
	@Column(columnDefinition = "varchar(25)")
	private String Business_EB_Bill;
	
	@Column(columnDefinition = "varchar(25)")
	private String Business_Address;
	
	@Column(columnDefinition = "varchar(25)")
	private String Nature_of_Business;
	
	
	private Integer Mobile_NO;
	
	@Column(columnDefinition = "varchar(35)")
	private String Mail_ID;
	
	
	private Long TRN;
	
	private Date TRN_DATE;
	
	private Long ARN;
	
	

	@Column(columnDefinition = "varchar(15)", nullable=false)
	private String GSTIN;
	
	@Column(columnDefinition = "varchar(25)")
	private String GST_USER;
	

	private String GST_PASS;
	
	
	@OneToOne(mappedBy="customer")
	private CustomerTable customerTable;
   // private List<ThingsToCartItem> thingsToCartItem;
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCompany_Name() {
		return company_Name;
	}

	public void setCompany_Name(String company_Name) {
		this.company_Name = company_Name;
	}

	public String getProprietor_Name() {
		return proprietor_Name;
	}

	public void setProprietor_Name(String proprietor_Name) {
		this.proprietor_Name = proprietor_Name;
	}

	public String getFather_Name() {
		return father_Name;
	}

	public void setFather_Name(String father_Name) {
		this.father_Name = father_Name;
	}



	public String getPan_No() {
		return pan_No;
	}

	public void setPan_No(String pan_No) {
		this.pan_No = pan_No;
	}

	public Long getAadhaar_No() {
		return Aadhaar_No;
	}

	public void setAadhaar_No(Long aadhaar_No) {
		Aadhaar_No = aadhaar_No;
	}

	

	public String getGSTIN() {
		return GSTIN;
	}

	public void setGSTIN(String gSTIN) {
		GSTIN = gSTIN;
	}

	public String getAadhaar_ADDRESS() {
		return Aadhaar_ADDRESS;
	}

	public void setAadhaar_ADDRESS(String aadhaar_ADDRESS) {
		Aadhaar_ADDRESS = aadhaar_ADDRESS;
	}

	public Date getDate_of_birth() {
		return Date_of_birth;
	}

	public void setDate_of_birth(Date date_of_birth) {
		Date_of_birth = date_of_birth;
	}

	public CustomerTable getCustomerTable() {
		return customerTable;
	}

	public void setCustomerTable(CustomerTable customerTable) {
		this.customerTable = customerTable;
	}

	public String getBusiness_EB_Bill() {
		return Business_EB_Bill;
	}

	public void setBusiness_EB_Bill(String business_EB_Bill) {
		Business_EB_Bill = business_EB_Bill;
	}

	public String getBusiness_Address() {
		return Business_Address;
	}

	public void setBusiness_Address(String business_Address) {
		Business_Address = business_Address;
	}

	public String getNature_of_Business() {
		return Nature_of_Business;
	}

	public void setNature_of_Business(String nature_of_Business) {
		Nature_of_Business = nature_of_Business;
	}

	public Integer getMobile_NO() {
		return Mobile_NO;
	}

	public void setMobile_NO(Integer mobile_NO) {
		Mobile_NO = mobile_NO;
	}

	public String getMail_ID() {
		return Mail_ID;
	}

	public void setMail_ID(String mail_ID) {
		Mail_ID = mail_ID;
	}

	public Long getTRN() {
		return TRN;
	}

	public void setTRN(Long tRN) {
		TRN = tRN;
	}

	public Date getTRN_DATE() {
		return TRN_DATE;
	}

	public void setTRN_DATE(Date tRN_DATE) {
		TRN_DATE = tRN_DATE;
	}

	public Long getARN() {
		return ARN;
	}

	public void setARN(Long aRN) {
		ARN = aRN;
	}

	public String getGST_USER() {
		return GST_USER;
	}

	public void setGST_USER(String gST_USER) {
		GST_USER = gST_USER;
	}

	public String getGST_PASS() {
		return GST_PASS;
	}

	public void setGST_PASS(String gST_PASS) {
		GST_PASS = gST_PASS;
	}

	

	
	
	
	
	
	
}
