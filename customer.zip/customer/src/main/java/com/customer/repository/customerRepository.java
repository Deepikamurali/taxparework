package com.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.customer.domain.Userforlg;

@Repository
public interface customerRepository extends JpaRepository <Userforlg,Long>{

	Userforlg findById(long id);

	Userforlg findByGSTIN(String gstin);

}
