package com.test.ESIPortal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.GstPortal.GSTPortalDetails;
import com.test.incometaxportal.IncomeTaxPortal;
import com.test.registration.CustomerRegistrationService;


@RestController
@RequestMapping("/api/ESIportal")
public class ESIportalDetailsWebService {
	@Autowired
	private ESIportalDetailsService service;
	
	@Autowired
	private CustomerRegistrationService registerservice;
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE, path = "/allESIportalDetails")
	public List<ESIportalDetails> getAllCustomer(){
		return service.getAllPfPortalDetails();
	}
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE, path = "/OneESIportalDetails/{id}")
	public ESIportalDetails getoneincometax(@PathVariable("id") long customerId){
		
				return  service.findOneESIportalDetails(customerId);
				}
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, path = "/addESIportalDetails")
	public String addCustomer(@RequestBody(required = true) ESIportalDetails customer) {
		try {
			Boolean find=registerservice.findcustomer(customer.getCustomerid());
			System.out.print(find);
			if(find == true ) {
			
				service.saveCustomer(customer);
				return "Successful";
			}
			else
				return "registeration not found to save";
			
			
		} catch (DataIntegrityViolationException e) {
			// TODO: handle exception
			return "Error Commit: "+e.getMessage();
		}
			
	}
	
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE, path= "/updatePfPortalDetails")
	public String updateCustomer(@RequestBody(required = true) ESIportalDetails customer) {
		try {
			Boolean find=service.findcustomer(customer.getCustomerid());
			System.out.print(find);
			if(find == true ) {
			
				service.saveCustomer(customer);
				return "update Successful";
			}
			else
				return "registeration not found to update";
			
			
		} catch (DataIntegrityViolationException e) {
			// TODO: handle exception
			return "Error Commit: "+e.getMessage();
		}
			
	}
	
	
	@DeleteMapping(consumes = MediaType.APPLICATION_JSON_VALUE,path="/DeletePfPortaldetails/{id}")
	public String DeleteDetails(@PathVariable("id") long customerId)
	{
		
		try {
			Boolean find=service.findcustomer(customerId);
			System.out.print(find);
			if(find == true ) {
				service.removeOne(customerId);
		     	return "deleted";
			}
			else
				return "no element found to delete";
		} catch (Exception e) {
			// TODO: handle exception
			return "Error Commit: "+e.getMessage();
		}
		
		
	}
}
