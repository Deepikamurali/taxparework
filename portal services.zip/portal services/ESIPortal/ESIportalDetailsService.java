package com.test.ESIPortal;

import java.util.List;

import com.test.GstPortal.GSTPortalDetails;

public interface ESIportalDetailsService {

	List<ESIportalDetails> getAllPfPortalDetails();

	void saveCustomer(ESIportalDetails customer);

	void removeOne(long customerId);

	ESIportalDetails findOneESIportalDetails(long customerId);

	Boolean findcustomer(long customerid);

}
