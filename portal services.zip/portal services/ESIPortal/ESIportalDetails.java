package com.test.ESIPortal;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.test.compositekeys.CustomerMasterID;

@Entity
@Table(name="ESI_Portal_Details")
@IdClass(CustomerMasterID.class)
public class ESIportalDetails 
{
	
	@Id
	@Column(name ="Customer_ID")
	private long customerid;
	
	@NotNull
	@Column(unique = true, name = "ESI_Number", columnDefinition = "bigint(15) DEFAULT 0")
	private Long esinumber;
	
	@NotNull
	@Column(unique = false, name = "ESI_User_Name", columnDefinition = "varchar(30)")
	private String esiUserName;
	
	@NotNull
	@Column(unique = false, name = "Password")
	private String password;
	
	@Column(columnDefinition = "varchar(4)",name="Financial_Year")
	private String FinancialYear;
	
	@Column(columnDefinition = "varchar(10)",name="Month")
	private String month;
	
	@Column(columnDefinition = "varchar(3)",name="Filling_Status")
	private String fillingStatus;
	
	@Column(unique = false, name = "Filling_Date")
	private Date fillingDate;

	public long getCustomerid() {
		return customerid;
	}

	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}

	
	public Long getEsinumber() {
		return esinumber;
	}

	public void setEsinumber(Long esinumber) {
		this.esinumber = esinumber;
	}

	public String  getEsiUserName() {
		return esiUserName;
	}

	public void setEsiUserName(String esiUserName) {
		this.esiUserName = esiUserName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFinancialYear() {
		return FinancialYear;
	}

	public void setFinancialYear(String financialYear) {
		FinancialYear = financialYear;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getFillingStatus() {
		return fillingStatus;
	}

	public void setFillingStatus(String fillingStatus) {
		this.fillingStatus = fillingStatus;
	}

	public Date getFillingDate() {
		return fillingDate;
	}

	public void setFillingDate(Date fillingDate) {
		this.fillingDate = fillingDate;
	}
	
	
}
