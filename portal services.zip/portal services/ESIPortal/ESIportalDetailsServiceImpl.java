package com.test.ESIPortal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.GstPortal.GSTPortalDetails;
import com.test.incometaxportal.IncomeTaxPortal;
import com.test.incometaxportal.IncomeTaxPortalRepositroy;

@Service
public class ESIportalDetailsServiceImpl implements  ESIportalDetailsService{
	@Autowired
	private ESIportalDetailsRepository repo;
	
	
	@Override
	public List<ESIportalDetails> getAllPfPortalDetails() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public void saveCustomer(ESIportalDetails customer) {
		repo.saveAndFlush(customer);
		
	}

	@Override
	public void removeOne(long customerId) {
		repo.deleteById(customerId);
		
	}

	@Override
	public ESIportalDetails findOneESIportalDetails(long customerId) {
		return repo.findBycustomerId(customerId);
	}

	@Override
	public Boolean findcustomer(long customerid) {
		ESIportalDetails cr=repo.findBycustomerId(customerid);
		System.out.print(cr);
		if(cr != null)
		{	
			System.out.print("trye");
		return true;
		}
		else
		{
			System.out.print("false");
		  return false;
	   }
	}

}
