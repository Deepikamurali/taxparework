package com.test.ESIPortal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.test.compositekeys.CustomerMasterID;

@Repository
public interface ESIportalDetailsRepository extends JpaRepository<ESIportalDetails, CustomerMasterID> {
	
	@Transactional
	@Modifying
	@Query("delete from ESIportalDetails b where b.customerid=:customerId")
	void deleteById(long customerId);
	
	
	@Query("select c from ESIportalDetails c where c.customerid=:customerid")
	ESIportalDetails findBycustomerId(long customerid);

}
