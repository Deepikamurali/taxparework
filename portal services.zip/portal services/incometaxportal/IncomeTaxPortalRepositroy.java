package com.test.incometaxportal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.test.GstPortal.GSTPortalDetails;
import com.test.compositekeys.CustomerMasterID;

@Repository
public interface IncomeTaxPortalRepositroy extends JpaRepository<IncomeTaxPortal, CustomerMasterID> {
	
	
	@Transactional
	@Modifying
	@Query("delete from IncomeTaxPortal b where b.customerid=:customerId")
	void deleteById(long customerId);

	@Query("select c from IncomeTaxPortal c where c.customerid=:customerId")
	IncomeTaxPortal findBycustomerId(long customerId);

}
