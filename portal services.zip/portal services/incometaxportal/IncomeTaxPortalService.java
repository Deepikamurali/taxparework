package com.test.incometaxportal;

import java.util.List;

import com.test.GstPortal.GSTPortalDetails;

public interface IncomeTaxPortalService {

	List<IncomeTaxPortal> getAllIncomeTaxPortal();

	void saveIncomeTax(IncomeTaxPortal customer);

	void removeOne(long customerId);

	Boolean findcustomer(long customerid);

	IncomeTaxPortal findOneincometax(long customerId);

}
