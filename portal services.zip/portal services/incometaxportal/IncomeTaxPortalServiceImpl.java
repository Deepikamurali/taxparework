package com.test.incometaxportal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.GstPortal.GSTPortalDetails;
import com.test.GstPortal.GSTPortalDetailsRepository;

@Service
public class IncomeTaxPortalServiceImpl implements IncomeTaxPortalService{

	@Autowired
	private IncomeTaxPortalRepositroy repo;

	@Override
	public List<IncomeTaxPortal> getAllIncomeTaxPortal() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public void saveIncomeTax(IncomeTaxPortal customer) {
		repo.saveAndFlush(customer);
		
	}

	@Override
	public void removeOne(long customerId) {
		repo.deleteById(customerId);
		
	}

	@Override
	public Boolean findcustomer(long customerid) {
		IncomeTaxPortal cr=repo.findBycustomerId(customerid);
		System.out.print(cr);
		if(cr != null)
		{	
			System.out.print("trye");
		return true;
		}
		else
		{
			System.out.print("false");
		  return false;
	   }
	}

	@Override
	public IncomeTaxPortal findOneincometax(long customerId) {
		// TODO Auto-generated method stub
		return repo.findBycustomerId(customerId);
	}

	
}
