package com.test.incometaxportal;

import java.io.Serializable;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.test.compositekeys.CustomerMasterID;

@Entity
@IdClass(CustomerMasterID.class)
@Table(name="IncomeTax_Portal")
public class IncomeTaxPortal  {

	
	@Id
	@Column(name ="Customer_ID")
	private long customerid;
	
	@NotNull
	@Column(name = "PAN_No", columnDefinition = "varchar(10) not null unique", updatable = true)
	private String panNo;
	
	@NotNull
	@Column(unique = false, name = "Password")
	private String password;
	
	@Column(columnDefinition = "varchar(10)",name="Financial_Year")
	private String FinancialYear;
	
	@Column(columnDefinition = "varchar(10)",name="Month")
	private String month;
	
	@Column(columnDefinition = "varchar(3)",name="Filing_Status")
	private String filingStatus;
	
	@Column(unique = false, name = "Filing_Date")
	private Date filingDate;
	
	@Column(columnDefinition = "varchar(3)",name="PFandEsi_applicable")
	private String PFandEsi;

	public long getCustomerid() {
		return customerid;
	}

	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFinancialYear() {
		return FinancialYear;
	}

	public void setFinancialYear(String financialYear) {
		FinancialYear = financialYear;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getFilingStatus() {
		return filingStatus;
	}

	public void setFilingStatus(String filingStatus) {
		this.filingStatus = filingStatus;
	}

	public Date getFilingDate() {
		return filingDate;
	}

	public void setFilingDate(Date filingDate) {
		this.filingDate = filingDate;
	}

	public String getPFandEsi() {
		return PFandEsi;
	}

	public void setPFandEsi(String pFandEsi) {
		PFandEsi = pFandEsi;
	}
	
	
	
}
