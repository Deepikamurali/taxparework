package com.test.registration;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;



@Entity
@Table(name="customer_registeration")
@SequenceGenerator(name = "CustomerMasterSeq", initialValue = 100, allocationSize = 1)

public class CustomerRegistration 
{
	

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CustomerMasterSeq")
	@Column(name ="Customer_ID")
	private long customerid;
	
	@NotNull
	@NotEmpty
	@Column(unique = false, length = 30, name = "Company_Name")
	private String companyName;
	
	@NotNull
	@NotEmpty
	@Column(unique = false, length = 30, name = "Proprietor_Name")
	private String proprietorName;
	
	@Column(unique = false, length = 30, name = "Father_Name")
	private String fatherName;
	
	@Column(unique = false,name = "DOB")
	private Date dateofbirth;
	
	@NotNull
	@Column(name = "PAN_No", columnDefinition = "varchar(10) not null unique", updatable = true)
	private String panNo;
	
	@NotNull
	@Column(unique = false, name = "AADHAR_NO", columnDefinition = "bigint(12) DEFAULT 0")
	private long aadhaarNo;
	
	@Column(unique = false, length = 150,name = "residental_Address")
	private String residentialAddress;
	
	@NotNull
	@NotEmpty
	@Column(unique = false, length = 30, name = "EB_Number")
	private String ebNo;
	
	@NotNull
	@NotEmpty
	@Column(unique = false, length = 150, name = "Business_Address")
	private String businessAddress;
	
	@NotNull
	@NotEmpty
	@Column(unique = false, length = 150, name = "Nature_Of_Business")
	private String natureofBusiness;
	
	@NotNull
	@Column(unique = false, name = "Customer_Phone_No", columnDefinition = "bigint(10) DEFAULT 0")
	private long customerphoneNo;
	
	@NotNull
	@NotEmpty
	@Column(unique = false, length = 40, name = "Customer_EMailId")
	private String customerEmail;

	public long getCustomerid() {
		return customerid;
	}

	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getProprietorName() {
		return proprietorName;
	}

	public void setProprietorName(String proprietorName) {
		this.proprietorName = proprietorName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public long getAadhaarNo() {
		return aadhaarNo;
	}

	public void setAadhaarNo(long aadhaarNo) {
		this.aadhaarNo = aadhaarNo;
	}

	public String getResidentialAddress() {
		return residentialAddress;
	}

	public void setResidentialAddress(String residentialAddress) {
		this.residentialAddress = residentialAddress;
	}

	public String getEbNo() {
		return ebNo;
	}

	public void setEbNo(String ebNo) {
		this.ebNo = ebNo;
	}

	public String getBusinessAddress() {
		return businessAddress;
	}

	public void setBusinessAddress(String businessAddress) {
		this.businessAddress = businessAddress;
	}

	public String getNatureofBusiness() {
		return natureofBusiness;
	}

	public void setNatureofBusiness(String natureofBusiness) {
		this.natureofBusiness = natureofBusiness;
	}

	public long getCustomerphoneNo() {
		return customerphoneNo;
	}

	public void setCustomerphoneNo(long customerphoneNo) {
		this.customerphoneNo = customerphoneNo;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	
	
	
}
