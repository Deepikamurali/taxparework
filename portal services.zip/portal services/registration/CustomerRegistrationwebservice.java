package com.test.registration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/api/register")
public class CustomerRegistrationwebservice 
{

	@Autowired
	private CustomerRegistrationService service;
	
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE, path = "/allcustomer")
	public List<CustomerRegistration > getAllCustomer(){
		return service.getAllCustomerRegistration ();
	}
	
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, path = "/addcustomer")
	public String addCustomer(@RequestBody(required = true) CustomerRegistration  customer) {
		try {
			
			service.saveCustomer(customer);
			return "Successful";
		} catch (DataIntegrityViolationException e) {
			// TODO: handle exception
			return "Error Commit: "+e.getMessage();
		}
			
	}
	
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE, path= "/updatecustomer")
	public String updateCustomer(@RequestBody(required = true) CustomerRegistration  customer) {
		try {
			
			service.saveCustomer(customer);
			return "update Successful";
		} catch (DataIntegrityViolationException e) {
			// TODO: handle exception
			return "Error Commit: "+e.getMessage();
		}
			
	}
	
	
	@DeleteMapping(consumes = MediaType.APPLICATION_JSON_VALUE,path="/customerDelete/{id}")
	public String DeleteDetails(@PathVariable("id") long customerId)
	{
		service.removeOne(customerId);
		
		
		return "deleted";
	}
	
}
