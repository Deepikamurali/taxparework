package com.test.registration;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface CustomerRegistrationRepository extends JpaRepository<CustomerRegistration,Long> {

	
	@Query("select c from CustomerRegistration c where c.customerid=:customerid")
	CustomerRegistration findBycustomer(long customerid);

}
