package com.test.registration;

import java.util.List;

public interface CustomerRegistrationService {

	List<CustomerRegistration> getAllCustomerRegistration();

	void saveCustomer(CustomerRegistration customer);

	void removeOne(long customerId);

	Boolean findcustomer(long customerid);

}
