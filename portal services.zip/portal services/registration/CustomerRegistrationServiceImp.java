package com.test.registration;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class CustomerRegistrationServiceImp implements CustomerRegistrationService{

	@Autowired
	private CustomerRegistrationRepository repo;
	
	@Override
	public List<CustomerRegistration> getAllCustomerRegistration() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public void saveCustomer(CustomerRegistration customer) {
		repo.saveAndFlush(customer);
		
	}

	@Override
	public void removeOne(long customerId) {
		repo.deleteById(customerId);
		
	}

	@Override
	public Boolean findcustomer(long customerid) {
		// TODO Auto-generated method stub
		CustomerRegistration cr=repo.findBycustomer(customerid);
		System.out.print(cr);
		if(cr != null)
		{	
			System.out.print("trye");
		return true;
		}
		else
		{
			System.out.print("false");
		  return false;
	   }
	}

	
}
