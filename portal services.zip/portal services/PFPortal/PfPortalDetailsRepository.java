package com.test.PFPortal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.test.compositekeys.CustomerMasterID;

@Repository
public interface PfPortalDetailsRepository extends JpaRepository<PfPortalDetails, CustomerMasterID> {
	
	@Transactional
	@Modifying
	@Query("delete from PfPortalDetails b where b.customerid=:customerId")
	void deleteById(long customerId);
	
	
	@Query("select c from PfPortalDetails c where c.customerid=:customerid")
	PfPortalDetails findBycustomerId(long customerid);

}
