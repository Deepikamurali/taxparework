package com.test.PFPortal;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.test.compositekeys.CustomerMasterID;

@Entity
@Table(name="PF_Portal_Details")
@IdClass(CustomerMasterID.class)
public class PfPortalDetails 
{
	
	@Id
	@Column(name ="Customer_ID")
	private long customerid;
	

	@Column(unique = false, name = "PF_Number", columnDefinition = "bigint(15) DEFAULT 0")
	private Long PfNumber;
	

	@Column(unique = false, name = "Pf_User_Name", columnDefinition = "varchar(30)")
	private String PfUserName;
	
	@NotNull
	@Column(unique = false, name = "Password")
	private String password;
	
	@Column(columnDefinition = "varchar(10)")
	private String FinancialYear;
	
	@Column(columnDefinition = "varchar(10)",name="Month")
	private String month;
	
	@Column(columnDefinition = "varchar(3)",name="Filing_Status")
	private String filingStatus;
	
	@Column(unique = false, name = "Filing_Date")
	private Date filingDate;

	public long getCustomerid() {
		return customerid;
	}

	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}

	public Long getPfNumber() {
		return PfNumber;
	}

	public void setPfNumber(Long pfNumber) {
		PfNumber = pfNumber;
	}

	public String getPfUserName() {
		return PfUserName;
	}

	public void setPfUserName(String pfUserName) {
		PfUserName = pfUserName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFinancialYear() {
		return FinancialYear;
	}

	public void setFinancialYear(String financialYear) {
		FinancialYear = financialYear;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getFilingStatus() {
		return filingStatus;
	}

	public void setFilingStatus(String filingStatus) {
		this.filingStatus = filingStatus;
	}

	public Date getFilingDate() {
		return filingDate;
	}

	public void setFilingDate(Date filingDate) {
		this.filingDate = filingDate;
	}
	
}
