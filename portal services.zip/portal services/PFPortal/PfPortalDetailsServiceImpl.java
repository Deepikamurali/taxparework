package com.test.PFPortal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.GstPortal.GSTPortalDetails;
import com.test.incometaxportal.IncomeTaxPortal;
import com.test.incometaxportal.IncomeTaxPortalRepositroy;

@Service
public class PfPortalDetailsServiceImpl implements  PfPortalDetailsService{
	@Autowired
	private PfPortalDetailsRepository repo;
	
	
	@Override
	public List<PfPortalDetails> getAllPfPortalDetails() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public void saveCustomer(PfPortalDetails customer) {
		repo.saveAndFlush(customer);
		
	}

	@Override
	public void removeOne(long customerId) {
		repo.deleteById(customerId);
		
	}

	@Override
	public PfPortalDetails findOnePfPortalDetails(long customerId) {
		return repo.findBycustomerId(customerId);
	}

	@Override
	public Boolean findcustomer(long customerid) {
		PfPortalDetails cr=repo.findBycustomerId(customerid);
		System.out.print(cr);
		if(cr != null)
		{	
			System.out.print("trye");
		return true;
		}
		else
		{
			System.out.print("false");
		  return false;
	   }
	}

}
