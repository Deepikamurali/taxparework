package com.test.PFPortal;

import java.util.List;

import com.test.GstPortal.GSTPortalDetails;

public interface PfPortalDetailsService {

	List<PfPortalDetails> getAllPfPortalDetails();

	void saveCustomer(PfPortalDetails customer);

	void removeOne(long customerId);

	PfPortalDetails findOnePfPortalDetails(long customerId);

	Boolean findcustomer(long customerid);

}
