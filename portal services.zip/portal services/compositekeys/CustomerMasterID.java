package com.test.compositekeys;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;

@IdClass(CustomerMasterID.class)
public class CustomerMasterID implements Serializable {

	@Column(name ="Customer_ID")
	private long customerid;
}
