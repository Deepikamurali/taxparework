package com.test.GstPortal;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;

import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.test.compositekeys.CustomerMasterID;

@Entity
@Table(name="GST_Portal")
@IdClass(CustomerMasterID.class)
public class GSTPortalDetails 
{
	
	
	@Id
	@Column(name ="Customer_ID")
	private long customerid;
	
	@NotNull
	@Column(unique = false, length = 40, name ="GST_Email")
	private String gstPortalEmail;
	
	@NotNull
	@Column(unique = false, name = "Email_Password")
	private String emailpwd;
	
	@NotNull
	@Column(unique = false, name = "GST_Portal_MobileNo", columnDefinition = "bigint(10) DEFAULT 0")
	private long GSTPortalMobileNo;
	
	@Column(unique = false, name = "TRN_No", columnDefinition = "bigint(15) DEFAULT 0")
	private long trnNo;
	
	@Column(unique = false, name = "TRN_Date")
	private Date trnDate;
	
	@Column(unique = false, length = 15, name = "ARN_No")
	private String arnNo;
	
	@NotNull
	@NotEmpty
	@Column(unique = false, length = 45,name = "GST_User")
	private String gstUser;
	
	@Column(unique = false, name = "GST_Passcode")
	private String gstPwd;
	
	@Column(columnDefinition = "varchar(10)")
	private String FinancialYear;
	
	@Column(columnDefinition = "varchar(10)",name="Month")
	private String month;
	
	@Column(columnDefinition = "varchar(3)",name="Filling_Status")
	private String fillingStatus;
	
	@Column(unique = false, name = "Filling_Date")
	private Date fillingDate;
	
	
	
	@Column(name="Re_marks")
	private String Remarks;







	public long getCustomerid() {
		return customerid;
	}



	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}



	public String getGstPortalEmail() {
		return gstPortalEmail;
	}



	public void setGstPortalEmail(String gstPortalEmail) {
		this.gstPortalEmail = gstPortalEmail;
	}



	public String getEmailpwd() {
		return emailpwd;
	}



	public void setEmailpwd(String emailpwd) {
		this.emailpwd = emailpwd;
	}



	public long getGSTPortalMobileNo() {
		return GSTPortalMobileNo;
	}



	public void setGSTPortalMobileNo(long gSTPortalMobileNo) {
		GSTPortalMobileNo = gSTPortalMobileNo;
	}



	public long getTrnNo() {
		return trnNo;
	}



	public void setTrnNo(long trnNo) {
		this.trnNo = trnNo;
	}



	public Date getTrnDate() {
		return trnDate;
	}



	public void setTrnDate(Date trnDate) {
		this.trnDate = trnDate;
	}



	public String getArnNo() {
		return arnNo;
	}



	public void setArnNo(String arnNo) {
		this.arnNo = arnNo;
	}



	public String getGstUser() {
		return gstUser;
	}



	public void setGstUser(String gstUser) {
		this.gstUser = gstUser;
	}



	public String getGstPwd() {
		return gstPwd;
	}



	public void setGstPwd(String gstPwd) {
		this.gstPwd = gstPwd;
	}



	public String getFinancialYear() {
		return FinancialYear;
	}



	public void setFinancialYear(String financialYear) {
		FinancialYear = financialYear;
	}



	public String getMonth() {
		return month;
	}



	public void setMonth(String month) {
		this.month = month;
	}



	public String getFillingStatus() {
		return fillingStatus;
	}



	public void setFillingStatus(String fillingStatus) {
		this.fillingStatus = fillingStatus;
	}



	public Date getFillingDate() {
		return fillingDate;
	}



	public void setFillingDate(Date fillingDate) {
		this.fillingDate = fillingDate;
	}



	public String getRemarks() {
		return Remarks;
	}



	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	
	
}
