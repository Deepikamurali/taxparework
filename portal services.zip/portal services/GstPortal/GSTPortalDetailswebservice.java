package com.test.GstPortal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.registration.CustomerRegistrationService;

@RestController
@RequestMapping("/api/gstportal")
public class GSTPortalDetailswebservice 
{

	@Autowired
	private GSTPortalDetailsService service;
	
	@Autowired
	private CustomerRegistrationService registerservice;
	
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE, path = "/allgstportaldetails")
	public List<GSTPortalDetails> getAllCustomer(){
		return service.getAllgstportaldetails();
	}
	
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE, path = "/Onegstportaldetails/{id}")
	public GSTPortalDetails getoneCustomer(@PathVariable("id") long customerId){
		
				return  service.findOnecustomer(customerId);
				}
	
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, path = "/addgstportaldetails")
	public String addCustomer(@RequestBody(required = true) GSTPortalDetails customer) {
		try {
			
			Boolean find=registerservice.findcustomer(customer.getCustomerid());
			System.out.print(find);
			if(find == true ) {
			
			service.saveCustomer(customer);
			return "Successful";
			}
			else
				return "registeration not found to save";
		} catch (DataIntegrityViolationException e) {
			// TODO: handle exception
			return "Error Commit: "+e.getMessage();
		}
		
			
	}
	
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE, path= "/updategstportaldetails")
	public String updateCustomer(@RequestBody(required = true) GSTPortalDetails customer) {
		try {
			Boolean find=service.findcustomer(customer.getCustomerid());
			System.out.print(find);
			if(find == true ) {
			service.saveCustomer(customer);
			return "update Successful";
			}
			else
				return "registeration id not found to update";
		} catch (DataIntegrityViolationException e) {
			// TODO: handle exception
			return "Error Commit: "+e.getMessage();
		}
			
	}
	
	
	@DeleteMapping(consumes = MediaType.APPLICATION_JSON_VALUE,path="/Deletegstportaldetails/{id}")
	public String DeleteDetails(@PathVariable("id") long customerId)
	{
		try {
			Boolean find=service.findcustomer(customerId);
			System.out.print(find);
			if(find == true ) {
				service.removeOne(customerId);
				return "deleted";
			}
			else
				return "no element found to delete";
		} catch (Exception e) {
			// TODO: handle exception
			return "Error Commit: "+e.getMessage();
		}
		
	}
	
}
