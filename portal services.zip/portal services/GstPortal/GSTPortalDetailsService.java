package com.test.GstPortal;

import java.util.List;

public interface GSTPortalDetailsService {

	List<GSTPortalDetails> getAllgstportaldetails();

	void saveCustomer(GSTPortalDetails customer);

	void removeOne(long customerId);

	Boolean findcustomer(long customerid);

	GSTPortalDetails findOnecustomer(long customerId);

}
