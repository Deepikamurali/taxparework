package com.test.GstPortal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.registration.CustomerRegistration;



@Service
public class GSTPortalDetailsServiceImp implements GSTPortalDetailsService{
	
	@Autowired
	private GSTPortalDetailsRepository repo;

	@Override
	public List<GSTPortalDetails> getAllgstportaldetails() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public void saveCustomer(GSTPortalDetails customer) {
		repo.saveAndFlush(customer);
		
	}

	@Override
	public void removeOne(long customerId) {
		repo.deleteBycustomerid(customerId);
		
	}

	@Override
	public Boolean findcustomer(long customerid) {
		GSTPortalDetails cr=repo.findBycustomer(customerid);
		System.out.print(cr);
		if(cr != null)
		{	
			System.out.print("trye");
		return true;
		}
		else
		{
			System.out.print("false");
		  return false;
	   }
	}

	@Override
	public GSTPortalDetails findOnecustomer(long customerId) {
		// TODO Auto-generated method stub
		return repo.findBycustomer(customerId);
	}

}
