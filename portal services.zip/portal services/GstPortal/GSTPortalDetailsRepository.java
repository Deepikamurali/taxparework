package com.test.GstPortal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.test.compositekeys.CustomerMasterID;

@Repository
public interface GSTPortalDetailsRepository extends JpaRepository<GSTPortalDetails, CustomerMasterID> {

	@Transactional
	@Modifying
	@Query("delete from GSTPortalDetails b where b.customerid=:customerId")
	void deleteBycustomerid(long customerId);

	@Query("select c from GSTPortalDetails c where c.customerid=:customerid")
	GSTPortalDetails findBycustomer(long customerid);

}
