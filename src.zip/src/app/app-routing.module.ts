import { NgModule } from '@angular/core';
import {Routes,RouterModule} from '@angular/router';
import{EmailComponent} from './components/email/email.component';
import { UploadFilesComponent } from './components/upload-files/upload-files.component';
const routes:Routes=[
  {
    path: 'upload',
    component: UploadFilesComponent
  },
  {
    path: 'email',
    component: EmailComponent
  },
]

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports:[RouterModule]
})
export class AppRoutingModule { 


}
