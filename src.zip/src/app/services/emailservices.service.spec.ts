import { TestBed } from '@angular/core/testing';

import { EmailservicesService } from './emailservices.service';

describe('EmailservicesService', () => {
  let service: EmailservicesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmailservicesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
