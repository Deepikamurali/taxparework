import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup,Validators} from '@angular/forms';
import {EmailservicesService} from 'F:/workhard/angular/angular-10-multiple-files-upload-master/src/app/services/emailservices.service';
@Component({
  selector: 'app-email',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.css']
})
export class EmailComponent implements OnInit {
  message1 = '';
  constructor(private eservice : EmailservicesService) { }

  ngOnInit(): void {
  }
  emaildata = new FormGroup({
    emailid : new FormControl('',[Validators.required,Validators.email]),
    subject : new FormControl('',[Validators.required]),
    message : new FormControl('',[Validators.required])
  })
  get emailid()
  {
    return this.emaildata.get('emailid')
  }
  get subject()
  {
    return this.emaildata.get('subject')
  }
  get message()
  {
    return this.emaildata.get('message')
  }
  onSubmit()
  { 
     
    console.warn(this.emaildata.value);
     this.eservice.sendEmail(this.emaildata.value).subscribe(
       (data)=> this.message1 =data.message
       //,console.warn("message is send",data),
     )
     this.emaildata.reset();
  }
}
